import USDT from './usdt.svg'
export const list = [
  {
    icon: USDT,
    name: "USDT",
  }
];
